#Модуль математических функций

#Суммирование номеров
def sum_numbers(*numbers):
    return sum(numbers)